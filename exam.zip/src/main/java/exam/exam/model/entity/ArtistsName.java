package exam.exam.model.entity;

public enum ArtistsName {
    QUEEN, METALLICA, MADONNA;
}
