package exam.exam.model.entity;

public enum GenreName {
    POP,ROCK,METAL,OTHER;
//    Pop, Rock, Metal and Other
}
